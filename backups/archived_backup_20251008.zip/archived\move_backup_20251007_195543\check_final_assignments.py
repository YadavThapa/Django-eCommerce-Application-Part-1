#!/usr/bin/env python3
"""
Check final product-store assignments after fixes.

This script is intended to be run standalone for quick checks. To keep
static analysis quiet this module avoids importing Django models at
top-level; Django is configured at runtime inside main().
"""

import os
import django  # type: ignore

# Ensure the settings module can be discovered when executed directly.
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "ecommerce_project.settings")


def main() -> None:
    """Print store product assignments and potential mismatches.

    Django is configured at runtime so this file can be imported by
    other tools without side-effects.
    """
    print("=== FINAL STORE ASSIGNMENTS ===")

    # Configure Django now that we are about to use ORM models.
    django.setup()

    # Import models after setup so static analysis doesn't require Django
    # to be importable at module-import time. Silence pylint's
    # import-outside-toplevel warning for this deliberate runtime import.
    # pylint: disable=import-outside-toplevel
    from shop.models import Store  # type: ignore[import]
    # pylint: enable=import-outside-toplevel

    # The ORM attributes trigger pylint "no-member" warnings because
    # Django's dynamically-added managers and related managers are not
    # visible to static analysis. Disable the check for the nearby
    # ORM usage to keep linters quiet; this is a no-op at runtime.
    # pylint: disable=no-member
    for store in (
        Store.objects.filter(is_active=True)
        .order_by("name")  # type: ignore[attr-defined]
    ):
        products = store.products.all()  # type: ignore[attr-defined]
        if products.exists():  # type: ignore[attr-defined]
            print(f"\n{store.name}:")
            for product in products:
                category_name = (
                    product.category.name
                    if product.category
                    else "No category"
                )
                print(f"  - {product.name} ({category_name})")

    print("\n=== POTENTIAL MISMATCHES TO WATCH ===")

    mismatches: list[str] = []

    for store in (
        Store.objects.filter(is_active=True)  # type: ignore[attr-defined]
    ):
        for product in store.products.all():  # type: ignore[attr-defined]
            store_name = store.name.lower()
            category_name = (
                product.category.name.lower() if product.category else ""
            )

            # Logic checks
            if "sports" in store_name and category_name not in ["sports"]:
                if category_name not in ["electronics"]:
                    # Electronics can be in sports stores (fitness tech)
                    mismatches.append(
                        f"  - {product.name} ({product.category.name}) "
                        f"in {store.name}"
                    )

            elif "fashion" in store_name and category_name not in ["clothing"]:
                mismatches.append(
                    f"  - {product.name} ({product.category.name}) "
                    f"in {store.name}"
                )

            elif "home" in store_name and category_name not in [
                "home & garden",
                "books",
            ]:
                # Books can be in home stores (cookbooks, home improvement)
                mismatches.append(
                    f"  - {product.name} ({product.category.name}) "
                    f"in {store.name}"
                )

            elif "tech" in store_name and category_name not in [
                "electronics",
                "books",
            ]:
                # Tech books are appropriate for tech stores
                mismatches.append(
                    f"  - {product.name} ({product.category.name}) "
                    f"in {store.name}"
                )

    # Re-enable the pylint no-member check for the remainder of the file.
    # pylint: enable=no-member

    if mismatches:
        print("Found potential mismatches:")
        for mismatch in mismatches:
            print(mismatch)
    else:
        print("No obvious mismatches found! ✅")


if __name__ == "__main__":
    main()

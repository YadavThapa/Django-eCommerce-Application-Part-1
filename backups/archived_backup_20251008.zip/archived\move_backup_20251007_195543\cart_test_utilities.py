"""Compatibility shim: cart test utilities.

This shim re-exports helpers from the consolidated tests tree under
`tests.legacy`. The heavy implementation was moved to `tests/legacy/` so
legacy imports keep working while keeping tests discoverable by test
runners.
"""

from tests.legacy.cart_test_utilities import (
    add_test_items_to_cart,
    test_cart_images,
    test_all_cart_images,
    test_cart_session,
    test_enhanced_cart,
)

__all__ = [
    "add_test_items_to_cart",
    "test_cart_images",
    "test_all_cart_images",
    "test_cart_session",
    "test_enhanced_cart",
]

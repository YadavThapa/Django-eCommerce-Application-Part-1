#!/usr/bin/env python
"""Organize all .md files into a single docs folder"""

import os
import shutil
from pathlib import Path
import argparse


def organize_md_files(dry_run: bool = False):
    """Move all .md files to a single docs folder.

    If ``dry_run`` is True the function will only print the actions it
    would take and won't modify files or directories. This is useful for
    testing the script without changing the project tree.
    """
    print("📚 ORGANIZING MARKDOWN FILES")
    print("=" * 50)

    base_dir = Path("C:/Users/hemja/OneDrive/Desktop/Django E-commerce")
    docs_dir = base_dir / "docs"

    # Create docs directory (or simulate creation in dry-run)
    if dry_run:
        print(f"📁 [DRY-RUN] Would create/verify docs directory: {docs_dir}")
    else:
        docs_dir.mkdir(exist_ok=True)
        print(f"📁 Created/verified docs directory: {docs_dir}")

    # Find all .md files (excluding .venv and other unnecessary directories)
    exclude_dirs = {".venv", "__pycache__", "node_modules", ".git"}
    md_files = []

    for root, dirs, files in os.walk(base_dir):
        # Remove excluded directories from the search
        dirs[:] = [d for d in dirs if d not in exclude_dirs]

        for file in files:
            if file.endswith(".md"):
                file_path = Path(root) / file
                # Skip files already in docs directory
                if "docs" not in str(file_path.relative_to(base_dir)).split(
                    os.sep
                ):
                    md_files.append(file_path)

    print(f"\n📋 Found {len(md_files)} .md files to organize:")

    moved_files = []
    skipped_files = []
    renamed_files = []

    for md_file in md_files:
        try:
            # Get relative path for display
            rel_path = md_file.relative_to(base_dir)
            print(f"\n📄 Processing: {rel_path}")

            # Determine destination filename
            dest_filename = md_file.name
            dest_path = docs_dir / dest_filename

            # Handle duplicates by adding a suffix
            counter = 1
            original_dest_path = dest_path
            while dest_path.exists():
                if dest_path.read_text(
                    encoding="utf-8", errors="ignore"
                ) == md_file.read_text(encoding="utf-8", errors="ignore"):
                    print("   ⏭️  Identical file exists, skipping")
                    skipped_files.append(str(rel_path))
                    break
                else:
                    # Different content, rename
                    name_part = md_file.stem
                    ext_part = md_file.suffix
                    dest_filename = f"{name_part}_{counter}{ext_part}"
                    dest_path = docs_dir / dest_filename
                    counter += 1
            else:
                # Move (or simulate move in dry-run)
                if dry_run:
                    if dest_path != original_dest_path:
                        print(
                            "   ✅ [DRY-RUN] Would move and rename to: "
                            f"{dest_filename}"
                        )
                        renamed_files.append((str(rel_path), dest_filename))
                    else:
                        print(
                            f"   ✅ [DRY-RUN] Would move to: {dest_filename}"
                        )
                        moved_files.append(str(rel_path))
                else:
                    shutil.move(str(md_file), str(dest_path))
                    if dest_path != original_dest_path:
                        print(f"   ✅ Moved and renamed to: {dest_filename}")
                        renamed_files.append((str(rel_path), dest_filename))
                    else:
                        print(f"   ✅ Moved to: {dest_filename}")
                        moved_files.append(str(rel_path))

        except (OSError, PermissionError) as e:
            print(f"   ❌ Error processing {md_file.name}: {e}")

    # Clean up empty directories (except essential ones)
    essential_dirs = {
        "shop",
        "ecommerce_project",
        "media",
        "static",
        "templates",
    }

    def remove_empty_dirs(path):
        """Remove empty directories recursively"""
        if not path.is_dir() or path.name in essential_dirs:
            return

        try:
            # Remove empty subdirectories
            for subdir in path.iterdir():
                if subdir.is_dir():
                    remove_empty_dirs(subdir)

            # Remove this directory if it's empty
            if not any(path.iterdir()):
                if (
                    path.name not in {"docs"}
                    and "documentation" in path.name.lower()
                ):
                    if dry_run:
                        print(
                            "   🗑️  [DRY-RUN] Would remove empty directory: "
                            + str(path.relative_to(base_dir))
                        )
                    else:
                        path.rmdir()
                        print(
                            "   🗑️  Removed empty directory: "
                            + str(path.relative_to(base_dir))
                        )
        except (OSError, PermissionError):
            pass  # Directory not empty or permission denied

    # Try to remove empty documentation directories
    for item in base_dir.iterdir():
        if item.is_dir() and "documentation" in item.name.lower():
            remove_empty_dirs(item)

    # Create index file (respect dry-run)
    create_docs_index(docs_dir, dry_run=dry_run)

    # Summary
    print("\n📊 ORGANIZATION SUMMARY:")
    print(f"   ✅ Files moved: {len(moved_files)}")
    print(f"   🔄 Files renamed: {len(renamed_files)}")
    print(f"   ⏭️  Files skipped (duplicates): {len(skipped_files)}")
    print("   📁 All files now in: docs/")

    print("\n📋 MOVED FILES:")
    for file in moved_files:
        print(f"   • {file}")

    if renamed_files:
        print("\n🔄 RENAMED FILES:")
        for original, new_name in renamed_files:
            print(f"   • {original} → {new_name}")

    if skipped_files:
        print("\n⏭️  SKIPPED FILES (identical duplicates):")
        for file in skipped_files:
            print(f"   • {file}")

    print("\n✅ MARKDOWN FILES ORGANIZATION COMPLETE!")
    print("📚 All documentation is now consolidated in the 'docs' folder")


def create_docs_index(docs_dir, dry_run: bool = False):
    """Create an index file for the docs directory.

    When ``dry_run`` is True the function will print the path that would be
    written and not actually write the file.
    """
    index_content = """# 📚 Django E-commerce Documentation

This folder contains all the documentation for the Django E-commerce project.

## 📋 Documentation Index

### 🔐 Authentication & Security

### 🛒 E-commerce Features

### 🎨 UI/UX Improvements

### 📊 Project Management

### 🔧 Technical Documentation

## 🚀 Quick Start

1. **Authentication System**: See
    `AUTHENTICATION_PERMISSIONS_SYSTEM.md`
2. **E-commerce Features**: Check
    `CHECKOUT_IMPLEMENTATION.md` and `VERIFIED_REVIEWS_COMPLETE.md`
3. **Usage Guide**: Follow
    `HOW_TO_USE_WORKING_FUNCTIONALITY.md`

## 📖 How to Use This Documentation

Each document is self-contained and includes:

## 🔄 Document Updates

This index is automatically generated. Last updated: October 5, 2025
"""
    index_path = docs_dir / "README.md"
    if dry_run:
        print(
            f"   📄 [DRY-RUN] Would create documentation index: {index_path}"
        )
    else:
        index_path.write_text(index_content, encoding="utf-8")
        print("   📄 Created documentation index: README.md")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Organize markdown files into docs/"
    )
    parser.add_argument(
        "-n",
        "--dry-run",
        action="store_true",
        help="Print actions without making filesystem changes",
    )

    args = parser.parse_args()
    organize_md_files(dry_run=args.dry_run)

"""Compatibility shim: re-export shop.models at project root.

Keep this shim minimal to preserve legacy imports like
`from models import Product` while avoiding duplicated code.
"""

from shop.models import (
    Cart,
    CartItem,
    Category,
    Order,
    OrderItem,
    PasswordResetToken,
    Product,
    Profile,
    Review,
    Store,
    User,
    create_user_profile,
    save_user_profile,
)

__all__ = [
    "Cart",
    "CartItem",
    "Category",
    "Order",
    "OrderItem",
    "PasswordResetToken",
    "Product",
    "Profile",
    "Review",
    "Store",
    "User",
    "create_user_profile",
    "save_user_profile",
]
